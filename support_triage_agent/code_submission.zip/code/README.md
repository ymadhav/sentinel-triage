# 🛡️ SentinelTriage AI: Secure Multi-Domain Support Agent

SentinelTriage AI is an enterprise-grade support triage system built for the **HackerRank Orchestrate Hackathon**. It uses a local Llama 3.2 model to categorize, answer, and audit support tickets for **HackerRank**, **Claude**, and **Visa**, while ensuring total data privacy through a local-first architecture.

---

## 🌟 Key Innovation: The Cyber Audit Layer
Unlike standard AI agents, SentinelTriage includes a **Security-First Audit Layer** that:
- **Redacts PII:** Automatically masks Emails and IP addresses before they reach the AI.
- **Risk Scoring:** Assigns a "Risk Score" to every ticket.
- **Threat Detection:** Detects keywords like "hack" or "breach" and escalates them directly to a Security Officer, bypassing the AI for safety.

---

## 📋 Prerequisites
Before you start, ensure you have the following installed:
1. **Python 3.10 or higher**
2. **Ollama** (Required for the local LLM). [Download here](https://ollama.com/)
3. **Llama 3.2 Model:** Open your terminal and run:
   ```bash
   ollama pull llama3.2
   ```

---

## 🛠️ Installation & Setup

### Step 1: Clone and Navigate
Open your terminal (or PowerShell) in the project root folder:
```powershell
cd support_triage_agent
```

### Step 2: Set Up Virtual Environment (Recommended)
```powershell
python -m venv venv
.\venv\Scripts\activate
```

### Step 3: Install Dependencies
```powershell
pip install pandas requests streamlit chromadb
```

---

## 🚀 How to Run the System

### Option 1: Terminal CLI (Official Submission Mode)
This mode processes the official tickets and generates the `output.csv` required for the hackathon.
```powershell
python code/main.py
```
* **Input:** `support_tickets/support_tickets.csv`
* **Output:** `support_tickets/output.csv`

### Option 2: Streamlit Dashboard (Security Analytics)
View the risk scores, PII redaction metrics, and the forensic audit trail in a professional UI.
```powershell
streamlit run code/app.py
```

---

## 📁 Project Structure
```text
support_triage_agent/
├── data/                    # Official support corpus (knowledge base)
├── support_tickets/         # Official inputs and final output.csv
└── code/                    # <-- EVERYTHING IN THIS FOLDER IS YOUR SUBMISSION
    ├── main.py              # CLI Entry point
    ├── app.py               # Analytics Dashboard
    ├── src/                 # Modular logic (Audit, LLM, Pipeline)
    └── data/logs/           # Forensic security logs
```

---

## ✅ Verification Checklist
To confirm the system is working perfectly:
1.  **Run the CLI:** Ensure `support_tickets/output.csv` is created with columns: `status`, `product_area`, `response`, `justification`, and `request_type`.
2.  **Check Privacy:** Add a ticket with an email to the input CSV; verify the output shows `[EMAIL_REDACTED]`.
3.  **Check Security:** Add a ticket with the word "hack"; verify it is automatically `escalated` with a `Critical` severity.

---

## ⚖️ Hackathon Compliance
- **Local Only:** No external API calls (OpenAI/Anthropic) are made for grounded answers.
- **Schema Strict:** Output values are strictly restricted to `replied`, `escalated`, `product_issue`, `feature_request`, `bug`, and `invalid`.
- **Forensics:** All security events are logged with timestamps in `code/data/logs/security_audit.jsonl`.

**Developed by Sudhanshu — B.Sc AI & ML**